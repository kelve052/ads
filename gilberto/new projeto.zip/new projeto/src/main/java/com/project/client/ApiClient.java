package com.project.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class ApiClient {

    @Autowired
    private RestTemplate restTemplate;

    public String getDataFromApi() {
        String apiUrl = "http://api.nodejs.com/data";
        return restTemplate.getForObject(apiUrl, String.class);
    }
}
